# سوق الريف الأول — Expo

نسخة Expo/React Native مصممة للبناء السحابي إلى APK/AAB.

## البناء السحابي
1. ثبّت EAS CLI أو استخدم بيئة سحابية تدعم Expo.
2. نفّذ `npm install` ثم `npx eas login`.
3. نفّذ `npx eas build -p android --profile preview` للحصول على APK للتجربة.
4. للإنتاج استخدم `npx eas build -p android --profile production` للحصول على AAB.
