import React, {useState} from 'react';
import {SafeAreaView, View, Text, TextInput, ScrollView, Pressable, StyleSheet} from 'react-native';
import {StatusBar} from 'expo-status-bar';
import {Ionicons} from '@expo/vector-icons';

const categories=[
 ['سيارات','car-outline'],['عقارات','home-outline'],['إلكترونيات','phone-portrait-outline'],['أثاث','bed-outline'],
 ['ملابس','shirt-outline'],['مواشي','paw-outline'],['زراعة','leaf-outline'],['خدمات','construct-outline']
];
const ads=[
 {title:'سيارة للبيع',price:'125,000,000',meta:'سوريا • اليوم'},
 {title:'هاتف Samsung Galaxy',price:'3,500,000',meta:'دمشق • منذ ساعتين'},
 {title:'أثاث منزلي كامل',price:'2,000,000',meta:'ريف دمشق • اليوم'}
];

export default function App(){
 const [currency,setCurrency]=useState('ل.س');
 const [tab,setTab]=useState(0);
 return <SafeAreaView style={s.safe}>
  <StatusBar style="dark"/>
  <View style={s.header}>
   <View><Text style={s.brand}>سوق الريف الأول</Text><Text style={s.sub}>كل شيء قريب منك</Text></View>
   <View style={s.headerBtns}>
    <Pressable onPress={()=>setCurrency(currency==='ل.س'?'$':'ل.س')} style={s.currency}><Text style={s.currencyText}>{currency}</Text></Pressable>
    <Ionicons name="notifications-outline" size={24} color="#1D2433"/>
   </View>
  </View>
  <ScrollView contentContainerStyle={s.content} showsVerticalScrollIndicator={false}>
   <View style={s.search}><Ionicons name="search-outline" size={22} color="#7A8291"/><TextInput placeholder="ابحث عن سيارة، عقار، هاتف..." placeholderTextColor="#8C94A3" style={s.searchInput}/></View>
   <View style={s.sectionRow}><Text style={s.sectionTitle}>الأقسام</Text><Text style={s.see}>عرض الكل</Text></View>
   <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.cats}>
    {categories.map(([name,icon])=><Pressable key={name} style={s.cat}><View style={s.catIcon}><Ionicons name={icon} size={27} color="#2E7D32"/></View><Text style={s.catText}>{name}</Text></Pressable>)}
   </ScrollView>
   <View style={s.sectionRow}><Text style={s.sectionTitle}>إعلانات مميزة</Text><Text style={s.see}>عرض الكل</Text></View>
   {ads.map(a=><Pressable key={a.title} style={s.card}><View style={s.photo}><Ionicons name="image-outline" size={34} color="#9AA2AE"/></View><View style={s.info}><Text style={s.adTitle}>{a.title}</Text><Text style={s.meta}>{a.meta}</Text><Text style={s.price}>{a.price} {currency}</Text></View><Ionicons name="heart-outline" size={24} color="#5D6675"/></Pressable>)}
   <View style={s.banner}><Text style={s.bannerTitle}>هل لديك شيء للبيع؟</Text><Text style={s.bannerText}>أضف إعلانك مجاناً ووصل إلى مشترين قريبين منك.</Text><Pressable style={s.sellBtn}><Text style={s.sellText}>أضف إعلاناً</Text></Pressable></View>
  </ScrollView>
  <View style={s.nav}>{[['الرئيسية','home-outline'],['المفضلة','heart-outline'],['بيع','add-circle'],['الرسائل','chatbubble-ellipses-outline'],['حسابي','person-outline']].map(([label,icon],i)=><Pressable key={label} onPress={()=>setTab(i)} style={s.navItem}><Ionicons name={icon} size={24} color={tab===i?'#2E7D32':'#7C8492'}/><Text style={[s.navText,tab===i&&s.navActive]}>{label}</Text></Pressable>)}</View>
 </SafeAreaView>
}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:'#F7F8FA'},header:{paddingHorizontal:18,paddingTop:12,paddingBottom:8,flexDirection:'row',justifyContent:'space-between',alignItems:'center',backgroundColor:'#FFF'},brand:{fontSize:22,fontWeight:'800',color:'#17202F'},sub:{fontSize:12,color:'#7A8291',marginTop:2},headerBtns:{flexDirection:'row',alignItems:'center',gap:14},currency:{paddingHorizontal:10,paddingVertical:7,borderRadius:10,backgroundColor:'#EEF6EE'},currencyText:{fontWeight:'800',color:'#2E7D32'},content:{padding:16,paddingBottom:30},search:{height:52,borderRadius:16,backgroundColor:'#FFF',borderWidth:1,borderColor:'#E4E7EC',flexDirection:'row',alignItems:'center',paddingHorizontal:14},searchInput:{flex:1,textAlign:'right',fontSize:14,color:'#1D2433',marginLeft:8},sectionRow:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginTop:22,marginBottom:10},sectionTitle:{fontSize:19,fontWeight:'800',color:'#17202F'},see:{fontSize:13,color:'#2E7D32',fontWeight:'700'},cats:{gap:10,paddingBottom:2},cat:{width:78,alignItems:'center'},catIcon:{width:62,height:62,borderRadius:18,backgroundColor:'#FFF',alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:'#E7EAEF'},catText:{fontSize:11,color:'#394150',marginTop:7},card:{backgroundColor:'#FFF',borderRadius:18,padding:12,marginBottom:11,flexDirection:'row',alignItems:'center',borderWidth:1,borderColor:'#ECEEF2'},photo:{width:92,height:92,borderRadius:14,backgroundColor:'#EEF0F3',alignItems:'center',justifyContent:'center'},info:{flex:1,marginHorizontal:12},adTitle:{fontSize:16,fontWeight:'800',color:'#1B2330'},meta:{fontSize:12,color:'#858D9B',marginTop:5},price:{fontSize:15,fontWeight:'800',color:'#2E7D32',marginTop:7},banner:{backgroundColor:'#E8F3E8',borderRadius:20,padding:18,marginTop:8},bannerTitle:{fontSize:18,fontWeight:'800',color:'#1E4F23'},bannerText:{fontSize:13,color:'#56705A',marginTop:6,lineHeight:20},sellBtn:{alignSelf:'flex-start',marginTop:12,backgroundColor:'#2E7D32',paddingHorizontal:18,paddingVertical:10,borderRadius:12},sellText:{color:'#FFF',fontWeight:'800'},nav:{height:72,backgroundColor:'#FFF',borderTopWidth:1,borderTopColor:'#E6E8EC',flexDirection:'row',justifyContent:'space-around',alignItems:'center'},navItem:{alignItems:'center',justifyContent:'center',minWidth:60},navText:{fontSize:10,color:'#7C8492',marginTop:4},navActive:{color:'#2E7D32',fontWeight:'800'}});
