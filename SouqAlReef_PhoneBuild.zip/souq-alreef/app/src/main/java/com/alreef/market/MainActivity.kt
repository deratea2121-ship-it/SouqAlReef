package com.alreef.market

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF087443)
private val DarkGreen = Color(0xFF00562F)
private val Gold = Color(0xFFF2B632)
private val Bg = Color(0xFFF6F8F6)

data class Product(val id:Long,val name:String,val price:Long,val category:String,val seller:String,val stock:Int)
data class CartLine(val product:Product,val qty:Int)
data class Order(val id:Long,val number:String,val total:Long,val status:String,val payment:String)

class MarketDb(context: Context): SQLiteOpenHelper(context,"alreef.db",null,1){
    override fun onCreate(db: SQLiteDatabase){
        db.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,email TEXT UNIQUE,password TEXT,role TEXT)")
        db.execSQL("CREATE TABLE sellers(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,store TEXT,commission REAL DEFAULT 5)")
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,price INTEGER,category TEXT,seller_id INTEGER,stock INTEGER,active INTEGER DEFAULT 1)")
        db.execSQL("CREATE TABLE cart(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,product_id INTEGER,qty INTEGER,UNIQUE(user_id,product_id))")
        db.execSQL("CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT,number TEXT,user_id INTEGER,total INTEGER,status TEXT,payment TEXT,created_at INTEGER)")
        db.execSQL("CREATE TABLE order_items(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER,product_id INTEGER,qty INTEGER,price INTEGER)")
        db.execSQL("CREATE TABLE favorites(user_id INTEGER,product_id INTEGER,UNIQUE(user_id,product_id))")
        db.execSQL("INSERT INTO users(name,email,password,role) VALUES('مدير النظام','admin@alreef.local','admin123','ADMIN')")
        db.execSQL("INSERT INTO users(name,email,password,role) VALUES('بائع تجريبي','seller@alreef.local','seller123','SELLER')")
        db.execSQL("INSERT INTO sellers(user_id,store) VALUES(2,'متجر الريف')")
        val products=listOf(
            arrayOf("زيت زيتون بكر ممتاز",120000,"مواد غذائية",1,50),
            arrayOf("سلة خضار طازجة",85000,"مواد غذائية",1,100),
            arrayOf("هاتف ذكي حديث",3200000,"إلكترونيات",1,20),
            arrayOf("طقم أواني منزلي",250000,"أدوات منزلية",1,30),
            arrayOf("حذاء رياضي",180000,"ملابس",1,25))
        products.forEach{p->val v=ContentValues().apply{put("name",p[0] as String);put("price",p[1] as Int);put("category",p[2] as String);put("seller_id",p[3] as Int);put("stock",p[4] as Int)};db.insert("products",null,v)}
    }
    override fun onUpgrade(db:SQLiteDatabase,old:Int,new:Int){}
    fun login(email:String,pw:String):Long{val c=readableDatabase.rawQuery("SELECT id FROM users WHERE email=? AND password=?",arrayOf(email,pw));val ok=if(c.moveToFirst())c.getLong(0) else -1;c.close();return ok}
    fun role(id:Long):String{val c=readableDatabase.rawQuery("SELECT role FROM users WHERE id=?",arrayOf(id.toString()));val r=if(c.moveToFirst())c.getString(0) else "GUEST";c.close();return r}
    fun products():List<Product>{val out=mutableListOf<Product>();val c=readableDatabase.rawQuery("SELECT p.id,p.name,p.price,p.category,COALESCE(s.store,'بائع'),p.stock FROM products p LEFT JOIN sellers s ON s.id=p.seller_id WHERE p.active=1 ORDER BY p.id DESC",null);while(c.moveToNext())out+=Product(c.getLong(0),c.getString(1),c.getLong(2),c.getString(3),c.getString(4),c.getInt(5));c.close();return out}
    fun cart(user:Long):List<CartLine>{val out=mutableListOf<CartLine>();val c=readableDatabase.rawQuery("SELECT p.id,p.name,p.price,p.category,COALESCE(s.store,'بائع'),p.stock,c.qty FROM cart c JOIN products p ON p.id=c.product_id LEFT JOIN sellers s ON s.id=p.seller_id WHERE c.user_id=?",arrayOf(user.toString()));while(c.moveToNext())out+=CartLine(Product(c.getLong(0),c.getString(1),c.getLong(2),c.getString(3),c.getString(4),c.getInt(5)),c.getInt(6));c.close();return out}
    fun addCart(user:Long,p:Product){val v=ContentValues().apply{put("user_id",user);put("product_id",p.id);put("qty",1)};readableDatabase.insertWithOnConflict("cart",null,v,SQLiteDatabase.CONFLICT_IGNORE);readableDatabase.execSQL("UPDATE cart SET qty=qty+1 WHERE user_id=? AND product_id=?",arrayOf(user,p.id))}
    fun clearCart(user:Long){readableDatabase.delete("cart","user_id=?",arrayOf(user.toString()))}
    fun createOrder(user:Long,payment:String):Long{val lines=cart(user);if(lines.isEmpty())return -1;val total=lines.sumOf{it.product.price*it.qty};val number="SR-${System.currentTimeMillis().toString().takeLast(8)}";val v=ContentValues().apply{put("number",number);put("user_id",user);put("total",total);put("status","جديد");put("payment",payment);put("created_at",System.currentTimeMillis())};val id=writableDatabase.insert("orders",null,v);lines.forEach{l->val x=ContentValues().apply{put("order_id",id);put("product_id",l.product.id);put("qty",l.qty);put("price",l.product.price)};writableDatabase.insert("order_items",null,x);writableDatabase.execSQL("UPDATE products SET stock=stock-? WHERE id=? AND stock>=?",arrayOf(l.qty,l.product.id,l.qty))};clearCart(user);return id}
    fun orders(user:Long):List<Order>{val out=mutableListOf<Order>();val c=readableDatabase.rawQuery("SELECT id,number,total,status,payment FROM orders WHERE user_id=? ORDER BY id DESC",arrayOf(user.toString()));while(c.moveToNext())out+=Order(c.getLong(0),c.getString(1),c.getLong(2),c.getString(3),c.getString(4));c.close();return out}
    fun register(name:String,email:String,pw:String):Long{val v=ContentValues().apply{put("name",name);put("email",email);put("password",pw);put("role","BUYER")};return writableDatabase.insert("users",null,v)}
}

class MainActivity:ComponentActivity(){
    override fun onCreate(b:Bundle?){super.onCreate(b);setContent{SouqApp(MarketDb(this))}}
}

@Composable fun SouqApp(db:MarketDb){
    var userId by remember{mutableLongStateOf(-1)}
    var tab by remember{mutableIntStateOf(0)}
    var refresh by remember{mutableIntStateOf(0)}
    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl){MaterialTheme(colorScheme=lightColorScheme(primary=Green,secondary=Gold,background=Bg)){
        if(userId<0) Login(db){userId=it}
        else Scaffold(bottomBar={NavigationBar{NavItem(Icons.Default.Home,"الرئيسية",tab==0){tab=0};NavItem(Icons.Default.GridView,"الأقسام",tab==1){tab=1};NavItem(Icons.Default.ShoppingCart,"السلة",tab==2){tab=2};NavItem(Icons.Default.ReceiptLong,"طلباتي",tab==3){tab=3};NavItem(Icons.Default.Person,"حسابي",tab==4){tab=4}}}){pad->Box(Modifier.padding(pad)){when(tab){0->Home(db,userId){refresh++};1->Categories(db,userId){refresh++};2->Cart(db,userId){refresh++};3->Orders(db,userId);4->Account(db,userId){userId=-1}}}}}
    }}
}

@Composable fun Login(db:MarketDb,onLogin:(Long)->Unit){var email by remember{mutableStateOf("")};var pw by remember{mutableStateOf("")};var register by remember{mutableStateOf(false)};var name by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().background(Bg).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text("سوق الريف الأول",fontSize=30.sp,fontWeight=FontWeight.Bold,color=Green);Text("ندعم منتجنا المحلي وننمي اقتصادنا",textAlign=TextAlign.Center,modifier=Modifier.padding(8.dp));if(register)TextField(name,{name=it},label={Text("الاسم")},modifier=Modifier.fillMaxWidth());TextField(email,{email=it},label={Text("البريد الإلكتروني")},modifier=Modifier.fillMaxWidth().padding(top=8.dp));TextField(pw,{pw=it},label={Text("كلمة المرور")},modifier=Modifier.fillMaxWidth().padding(top=8.dp));if(error.isNotEmpty())Text(error,color=Color.Red,modifier=Modifier.padding(8.dp));Button(onClick={if(register){val id=db.register(name,email,pw);if(id>0)onLogin(id)else error="البريد مستخدم أو البيانات غير صحيحة"}else{val id=db.login(email,pw);if(id>0)onLogin(id)else error="بيانات الدخول غير صحيحة"}},modifier=Modifier.fillMaxWidth().padding(top=14.dp)){Text(if(register)"إنشاء حساب" else "تسجيل الدخول")};TextButton(onClick={register=!register}){Text(if(register)"لدي حساب بالفعل" else "إنشاء حساب جديد")};Text("حساب الإدارة التجريبي: admin@alreef.local / admin123",fontSize=10.sp,color=Color.Gray)} }

@Composable fun Header(){Row(Modifier.fillMaxWidth().background(Green).padding(16.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){Text("سوق الريف الأول",color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Bold);Icon(Icons.Default.Notifications,null,tint=Color.White)}}
@Composable fun NavItem(icon:androidx.compose.ui.graphics.vector.ImageVector,label:String,selected:Boolean,onClick:()->Unit)=NavigationBarItem(selected,onClick,{Icon(icon,null)},label={Text(label,fontSize=10.sp)})
@Composable fun Home(db:MarketDb,user:Long,refresh:()->Unit){val ps=db.products();Column(Modifier.fillMaxSize().background(Bg)){Header();Text("ندعم منتجنا المحلي وننمي اقتصادنا",fontSize=20.sp,fontWeight=FontWeight.Bold,color=DarkGreen,modifier=Modifier.padding(16.dp));Text("كل ما تحتاجه في مكان واحد",modifier=Modifier.padding(horizontal=16.dp));LazyColumn{items(ps){p->ProductCard(p){db.addCart(user,p);refresh()}}}}}
@Composable fun ProductCard(p:Product,onAdd:()->Unit){Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=5.dp),shape=RoundedCornerShape(16.dp)){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(72.dp).background(Color(0xFFE8F0EA),RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.Inventory2,null,tint=Green)};Column(Modifier.weight(1f).padding(horizontal=12.dp)){Text(p.name,fontWeight=FontWeight.Bold);Text(p.seller,fontSize=12.sp,color=Color.Gray);Text("${p.price} ل.س",color=Green,fontWeight=FontWeight.Bold);Text("المخزون: ${p.stock}",fontSize=11.sp)};IconButton(onClick=onAdd){Icon(Icons.Default.AddShoppingCart,null,tint=Green)}}}}
@Composable fun Categories(db:MarketDb,user:Long,add:()->Unit){SimpleList("الأقسام",db.products().map{it.category}.distinct())}
@Composable fun Cart(db:MarketDb,user:Long,refresh:()->Unit){val lines=db.cart(user);val total=lines.sumOf{it.product.price*it.qty};Column(Modifier.fillMaxSize().background(Bg)){Header();Text("سلة المشتريات",fontSize=24.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(18.dp));if(lines.isEmpty())Text("السلة فارغة",modifier=Modifier.padding(18.dp))else{LazyColumn(Modifier.weight(1f)){items(lines){l->Text("${l.product.name} × ${l.qty} = ${l.product.price*l.qty} ل.س",modifier=Modifier.fillMaxWidth().padding(14.dp))}}Text("الإجمالي: $total ل.س",fontWeight=FontWeight.Bold,fontSize=20.sp,modifier=Modifier.padding(16.dp));Button(onClick={db.createOrder(user,"الدفع عند الاستلام");refresh()},modifier=Modifier.fillMaxWidth().padding(16.dp)){Text("تأكيد الطلب والدفع عند الاستلام")};Button(onClick={db.createOrder(user,"الدفع الإلكتروني");refresh()},modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp)){Text("الدفع الإلكتروني (يتطلب بوابة دفع)")}}}}
@Composable fun Orders(db:MarketDb,user:Long){val os=db.orders(user);SimpleList("طلباتي",os.map{"${it.number} — ${it.status} — ${it.total} ل.س — ${it.payment}"})}
@Composable fun Account(db:MarketDb,user:Long,logout:()->Unit){Column(Modifier.fillMaxSize().background(Bg)){Header();Text("حسابي",fontSize=24.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(18.dp));Text("الدور: ${db.role(user)}",modifier=Modifier.padding(18.dp));Button(onClick=logout,modifier=Modifier.fillMaxWidth().padding(16.dp)){Text("تسجيل الخروج")}}}
@Composable fun SimpleList(title:String,items:List<String>){Column(Modifier.fillMaxSize().background(Bg)){Header();Text(title,fontSize=24.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(18.dp));LazyColumn{items(items){t->Card(Modifier.fillMaxWidth().padding(8.dp)){Text(t,modifier=Modifier.padding(18.dp))}}}}}
